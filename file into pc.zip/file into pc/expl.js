const list = document.getElementById("list");

list.addEventListener("click", function(event) {
    const target = event.target;

    // Check if the clicked element is an LI element
    if (target.tagName === "LI") {
        // Toggle the "selected" class to highlight the clicked item
        target.classList.toggle("selected");
    }
});

// 8527705952